import review1 from "../images/reviews/review1.png"
import review2 from "../images/reviews/review2.png"
import review3 from "../images/reviews/review3.png"
import review4 from "../images/reviews/review4.png"
import review5 from "../images/reviews/review5.png"

const reviews = [ review1, review2, review3, review4, review5 ]

export default reviews