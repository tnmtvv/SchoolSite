export const UPLOAD_FILE = 'UPLOAD_FILE';
export const VIEW_FILE = 'VIEW_FILE';
export const RESET_VARIABLE = 'RESET_VARIABLE';